from ._rooms_client_async import RoomsClient

__all__ = [
    'RoomsClient',
]
